from pathlib import Path


# ============================================================
# PROJECT ROOT
# ============================================================

PROJECT_ROOT = Path(__file__).resolve().parents[2]


# ============================================================
# SAFE PATH
# ============================================================

def safe_path(relative_path: str) -> Path:
    requested_path = (PROJECT_ROOT / relative_path).resolve()

    try:
        requested_path.relative_to(PROJECT_ROOT)
    except ValueError:
        raise ValueError(
            "Access denied: path is outside the project directory."
        )

    return requested_path


# ============================================================
# LIST FILES
# ============================================================

def list_files(directory: str = ".") -> str:

    directory_path = safe_path(directory)

    if not directory_path.exists():
        return f"Directory not found: {directory}"

    if not directory_path.is_dir():
        return f"Not a directory: {directory}"

    ignored = {
        ".git",
        ".venv",
        "__pycache__",
        ".pytest_cache",
        "node_modules",
    }

    results = []

    for path in directory_path.rglob("*"):

        if any(part in ignored for part in path.parts):
            continue

        if path.is_file():
            results.append(
                str(path.relative_to(PROJECT_ROOT))
            )

    if not results:
        return "No files found."

    return "\n".join(sorted(results))


# ============================================================
# READ FILE
# ============================================================

def read_file(file_path: str) -> str:

    path = safe_path(file_path)

    if not path.exists():
        return f"File not found: {file_path}"

    if not path.is_file():
        return f"Not a file: {file_path}"

    try:
        return path.read_text(encoding="utf-8")

    except UnicodeDecodeError:
        return (
            f"Cannot read {file_path}: "
            "file is not a UTF-8 text file."
        )


# ============================================================
# WRITE FILE
# ============================================================

def write_file(
    file_path: str,
    content: str,
) -> str:

    path = safe_path(file_path)

    path.parent.mkdir(
        parents=True,
        exist_ok=True,
    )

    path.write_text(
        content,
        encoding="utf-8",
    )

    return f"File written successfully: {file_path}"


# ============================================================
# UPDATE FILE
# ============================================================

def update_file(
    file_path: str,
    old_text: str,
    new_text: str,
) -> str:

    path = safe_path(file_path)

    if not path.exists():
        return f"File not found: {file_path}"

    content = path.read_text(
        encoding="utf-8"
    )

    if old_text not in content:
        return (
            f"Could not find the requested text "
            f"in {file_path}."
        )

    updated_content = content.replace(
        old_text,
        new_text,
        1,
    )

    path.write_text(
        updated_content,
        encoding="utf-8",
    )

    return f"File updated successfully: {file_path}"


# ============================================================
# SEARCH CODE
# ============================================================

def search_code(
    query: str,
    directory: str = ".",
) -> str:
    """
    Search for a text string inside project source files.
    """

    directory_path = safe_path(directory)

    if not directory_path.exists():
        return f"Directory not found: {directory}"

    ignored = {
        ".git",
        ".venv",
        "__pycache__",
        ".pytest_cache",
        "node_modules",
    }

    results = []

    for path in directory_path.rglob("*"):

        if not path.is_file():
            continue

        if any(part in ignored for part in path.parts):
            continue

        # Only search common source/config files
        if path.suffix.lower() not in {
            ".py",
            ".js",
            ".jsx",
            ".ts",
            ".tsx",
            ".json",
            ".yaml",
            ".yml",
            ".md",
            ".txt",
            ".sql",
            ".html",
            ".css",
        }:
            continue

        try:
            content = path.read_text(
                encoding="utf-8"
            )

        except (UnicodeDecodeError, OSError):
            continue

        for line_number, line in enumerate(
            content.splitlines(),
            start=1,
        ):

            if query.lower() in line.lower():

                results.append(
                    f"{path.relative_to(PROJECT_ROOT)}:"
                    f"{line_number}: "
                    f"{line.strip()}"
                )

    if not results:
        return f"No matches found for: {query}"

    return "\n".join(results)