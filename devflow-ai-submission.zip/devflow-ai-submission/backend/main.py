import os
import asyncio

from dotenv import load_dotenv
from openai import AsyncOpenAI

from agents import (
    Runner,
    RunConfig,
    OpenAIChatCompletionsModel,
)

from backend.agents.requirements import requirements_agent
from backend.agents.codebase import codebase_agent
from backend.agents.planner import planner_agent
from backend.agents.developer import developer_agent
from backend.agents.verifier import verifier_agent


# ============================================================
# ENVIRONMENT
# ============================================================

load_dotenv()

GROQ_API_KEY = os.getenv("GROQ_API_KEY")

if not GROQ_API_KEY:
    raise RuntimeError(
        "GROQ_API_KEY not found in .env"
    )


# ============================================================
# GROQ CLIENT
# ============================================================

groq_client = AsyncOpenAI(
    api_key=GROQ_API_KEY,
    base_url="https://api.groq.com/openai/v1",
)


# ============================================================
# GROQ MODEL
# ============================================================

groq_model = OpenAIChatCompletionsModel(
    model="llama-3.1-8b-instant",
    openai_client=groq_client,
)


# ============================================================
# RUN CONFIG
# ============================================================

run_config = RunConfig(
    model=groq_model,
)


# ============================================================
# LIMIT OUTPUT SIZE
# ============================================================

def limit_text(
    text: str,
    max_chars: int = 10000,
) -> str:

    if not text:
        return ""

    if len(text) <= max_chars:
        return text

    return (
        text[:max_chars]
        + "\n\n[OUTPUT TRUNCATED]"
    )


# ============================================================
# RUN AGENT
# ============================================================

async def run_agent(
    agent,
    prompt: str,
):

    try:

        result = await Runner.run(
            agent,
            prompt,
            run_config=run_config,
        )

        return result.final_output

    except Exception as e:

        print()
        print("[DevFlow] ERROR")
        print("-" * 60)
        print(type(e).__name__)
        print(str(e))
        print("-" * 60)
        print()

        raise


# ============================================================
# MAIN
# ============================================================

async def main():

    print()
    print("=" * 60)
    print("                    DEVFLOW AI")
    print("=" * 60)
    print()

    # ========================================================
    # USER REQUIREMENT
    # ========================================================

    requirement = input(
        "Enter the feature/request you want to implement:\n\n> "
    ).strip()

    if not requirement:

        print()
        print(
            "[DevFlow] No requirement provided."
        )

        return


    # ========================================================
    # 1. REQUIREMENTS ANALYST
    # ========================================================

    print()
    print(
        "[DevFlow] Starting analysis..."
    )
    print()

    print(
        "[DevFlow] → Requirements Analyst"
    )

    requirements_prompt = f"""
Analyze this software requirement.

Requirement:
{requirement}

Return ONLY:

1. Feature
2. Goal
3. Functional requirements
4. Non-functional requirements
5. Acceptance criteria

IMPORTANT:
- Do not invent requirements.
- Clearly distinguish requested requirements from assumptions.
- Keep the response concise.
"""

    requirements_result = await run_agent(
        requirements_agent,
        requirements_prompt,
    )

    requirements_result = limit_text(
        requirements_result,
        7000,
    )

    print(
        "[DevFlow] Requirements analysis completed."
    )


    # ========================================================
    # 2. CODEBASE ANALYST
    # ========================================================

    print()
    print(
        "[DevFlow] → Codebase Analyst"
    )

    codebase_prompt = f"""
Analyze the existing codebase for this feature.

USER REQUIREMENT:
{requirement}

REQUIREMENTS ANALYSIS:
{requirements_result}

IMPORTANT:

- Inspect only files relevant to this feature.
- Do NOT list the entire repository.
- Do NOT dump complete source files.
- Use tools selectively.
- Use search_code for targeted searches.
- Read only relevant files.
- Keep the final response concise.

Return ONLY:

# CODEBASE ANALYSIS

## Relevant Files

## Existing Architecture

## Existing Functionality

## Required Changes

## Potential Conflicts

## Missing Components

Do not include large source-code blocks.
"""

    codebase_result = await run_agent(
        codebase_agent,
        codebase_prompt,
    )

    codebase_result = limit_text(
        codebase_result,
        8500,
    )

    print(
        "[DevFlow] Codebase analysis completed."
    )


    # ========================================================
    # 3. DEVELOPMENT PLANNER
    # ========================================================

    print()
    print(
        "[DevFlow] → Development Planner"
    )

    planner_prompt = f"""
Create an implementation plan for this feature.

USER REQUIREMENT:
{requirement}

REQUIREMENTS ANALYSIS:
{requirements_result}

CODEBASE ANALYSIS:
{codebase_result}

Return:

# DEVELOPMENT PLAN

## 1. Feature Summary

## 2. Existing System

## 3. Files to Modify

## 4. Files to Create

## 5. Dependencies

## 6. API Changes

## 7. Database Changes

## 8. Implementation Order

## 9. Testing Strategy

## 10. Security Considerations

## 11. Risks

## 12. Acceptance Criteria

IMPORTANT:

- Do not invent files unnecessarily.
- Reuse the existing architecture.
- Do not duplicate existing functionality.
- Do not assume requirements that were not requested.
- Keep the plan concise.
"""

    planner_result = await run_agent(
        planner_agent,
        planner_prompt,
    )

    planner_result = limit_text(
        planner_result,
        8500,
    )

    print(
        "[DevFlow] Development plan completed."
    )


    # ========================================================
    # 4. DEVELOPER
    # ========================================================

    print()
    print(
        "[DevFlow] → Developer"
    )

    developer_prompt = f"""
Implement the requested feature in the existing codebase.

USER REQUIREMENT:
{requirement}

REQUIREMENTS ANALYSIS:
{requirements_result}

CODEBASE ANALYSIS:
{codebase_result}

DEVELOPMENT PLAN:
{planner_result}

IMPORTANT:

1. Inspect relevant files before modifying them.
2. Modify only files necessary for the feature.
3. Reuse the existing architecture.
4. Do not create duplicate modules.
5. Do not rewrite unrelated code.
6. Preserve existing functionality.
7. Use the available filesystem tools.
8. Verify your changes where possible.
9. Do not claim tests were executed unless they were actually executed.
10. Do not dump entire files into the response.

Return:

# IMPLEMENTATION REPORT

## Status

## Files Modified

## Files Created

## Changes Made

## Verification

## Remaining Issues
"""

    developer_result = await run_agent(
        developer_agent,
        developer_prompt,
    )

    developer_result = limit_text(
        developer_result,
        8500,
    )

    print(
        "[DevFlow] Developer completed."
    )


    # ========================================================
    # 5. VERIFICATION AGENT
    # ========================================================

    print()
    print(
        "[DevFlow] → Verification Agent"
    )

    verification_prompt = f"""
Independently verify the Developer's implementation.

USER REQUIREMENT:
{requirement}

REQUIREMENTS ANALYSIS:
{requirements_result}

CODEBASE ANALYSIS:
{codebase_result}

DEVELOPMENT PLAN:
{planner_result}

DEVELOPER REPORT:
{developer_result}

IMPORTANT:

- Inspect the actual project files.
- Do not blindly trust the Developer report.
- Check whether the requested feature actually exists.
- Check relevant imports.
- Check application integration.
- Check for obvious syntax or implementation problems.
- Look for existing tests.
- Do not claim a test was executed unless there is evidence.
- Do not dump entire source files.
- Keep the response concise.

Return exactly:

# VERIFICATION REPORT

## Status

PASS or FAIL

## Implementation Check

## Integration Check

## Test Check

## Issues

## Recommendation
"""

    verification_result = await run_agent(
        verifier_agent,
        verification_prompt,
    )

    verification_result = limit_text(
        verification_result,
        7000,
    )

    print(
        "[DevFlow] Verification completed."
    )


    # ========================================================
    # FINAL OUTPUT
    # ========================================================

    print()
    print("=" * 60)
    print("                    DEVFLOW RESULT")
    print("=" * 60)


    # ========================================================
    # REQUIREMENTS
    # ========================================================

    print()
    print(
        "# REQUIREMENTS ANALYSIS"
    )

    print(
        requirements_result
    )


    # ========================================================
    # CODEBASE
    # ========================================================

    print()
    print(
        "# CODEBASE ANALYSIS"
    )

    print(
        codebase_result
    )


    # ========================================================
    # PLAN
    # ========================================================

    print()
    print(
        "# DEVELOPMENT PLAN"
    )

    print(
        planner_result
    )


    # ========================================================
    # IMPLEMENTATION
    # ========================================================

    print()
    print(
        "# IMPLEMENTATION REPORT"
    )

    print(
        developer_result
    )


    # ========================================================
    # VERIFICATION
    # ========================================================

    print()
    print(
        "# VERIFICATION REPORT"
    )

    print(
        verification_result
    )


    # ========================================================
    # COMPLETE
    # ========================================================

    print()
    print("=" * 60)
    print(
        "                    DEVFLOW COMPLETE"
    )
    print("=" * 60)
    print()


# ============================================================
# ENTRY POINT
# ============================================================

if __name__ == "__main__":

    try:

        asyncio.run(main())

    except KeyboardInterrupt:

        print()
        print(
            "[DevFlow] Process interrupted."
        )

    except Exception as e:

        print()
        print(
            "[DevFlow] Fatal error:"
        )
        print(
            f"{type(e).__name__}: {e}"
        )