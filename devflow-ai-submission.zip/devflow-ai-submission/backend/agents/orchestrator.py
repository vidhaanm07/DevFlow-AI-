from agents import Agent, Runner, function_tool

from backend.model import groq_model
from backend.agents.requirements import requirements_agent
from backend.agents.codebase import codebase_agent
from backend.agents.planner import planner_agent


# ============================================================
# REQUIREMENTS ANALYST TOOL
# ============================================================

@function_tool
async def run_requirements_agent(request: str) -> str:
    """
    Run the Requirements Analyst.

    Args:
        request: The user's project or feature request.
    """

    print()
    print("[DevFlow] → Requirements Analyst")
    print()

    result = await Runner.run(
        requirements_agent,
        request,
    )

    return result.final_output


# ============================================================
# CODEBASE ANALYST TOOL
# ============================================================

@function_tool
async def run_codebase_agent(request: str) -> str:
    """
    Run the Codebase Analyst.

    Args:
        request: The user's project or feature request.
    """

    print()
    print("[DevFlow] → Codebase Analyst")
    print()

    result = await Runner.run(
        codebase_agent,
        request,
    )

    return result.final_output


# ============================================================
# DEVELOPMENT PLANNER TOOL
# ============================================================

@function_tool
async def run_planner_agent(analysis: str) -> str:
    """
    Run the Development Planner.

    Args:
        analysis: Requirements and/or codebase analysis that
                  the planner should convert into an
                  implementation plan.
    """

    print()
    print("[DevFlow] → Development Planner")
    print()

    result = await Runner.run(
        planner_agent,
        analysis,
    )

    return result.final_output


# ============================================================
# ORCHESTRATOR
# ============================================================

orchestrator_agent = Agent(
    name="DevFlow Orchestrator",

    model=groq_model,

    tools=[
        run_requirements_agent,
        run_codebase_agent,
        run_planner_agent,
    ],

    instructions="""
You are the main Orchestrator of DevFlow AI.

Your job is to understand the user's request and coordinate
the specialist agents.


============================================================
AVAILABLE SPECIALISTS
============================================================

1. Requirements Analyst

Handles:

- Requirements gathering
- Functional requirements
- Non-functional requirements
- User stories
- Acceptance criteria
- Scope definition
- Feature specifications


2. Codebase Analyst

Handles:

- Existing project analysis
- Code analysis
- Architecture analysis
- File analysis
- Dependency analysis
- Backend analysis
- Source-code searching
- Finding files that need modification


3. Development Planner

Handles:

- Turning analysis into an implementation plan
- Files to modify
- Files to create
- Dependencies
- API changes
- Backend changes
- Frontend changes
- Database changes
- Implementation order
- Testing plan
- Security considerations
- Risks
- Acceptance criteria


============================================================
ROUTING
============================================================

For requirements-only requests:

Use:

run_requirements_agent


For existing-codebase analysis:

Use:

run_codebase_agent


For implementation planning:

Use:

run_planner_agent


For a request involving an existing project and a feature,
the preferred workflow is:

1. Run Codebase Analyst.
2. Give the resulting analysis to Development Planner.
3. Return the Development Planner's result.


============================================================
IMPORTANT
============================================================

Do not invent information.

Do not claim that a specialist was used unless it was
actually executed.

Do not modify files.

The specialists perform the actual analysis.

The planner produces a plan only.


============================================================
CURRENT WORKFLOW
============================================================

For an existing-project feature request:

USER
  ↓
ORCHESTRATOR
  ↓
CODEBASE ANALYST
  ↓
CODEBASE ANALYSIS
  ↓
DEVELOPMENT PLANNER
  ↓
IMPLEMENTATION PLAN
  ↓
USER


For requirements-only requests:

USER
  ↓
ORCHESTRATOR
  ↓
REQUIREMENTS ANALYST
  ↓
REQUIREMENTS
  ↓
USER
"""
)