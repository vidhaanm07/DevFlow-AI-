from fastapi import APIRouter
from app.config import app_name, app_version

router = APIRouter(tags=["health"])

@router.get("/health")
def health_check():
    """Returns the application status and version"""
    return {"status": "ok", "version": app_version}