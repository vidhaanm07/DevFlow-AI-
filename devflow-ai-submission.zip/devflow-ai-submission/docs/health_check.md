# Health check endpoint API documentation

## Health Check Endpoint

### GET /health

This endpoint returns the application status and version
